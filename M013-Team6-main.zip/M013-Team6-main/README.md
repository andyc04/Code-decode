# M013-Team6
ECS 101 project for compression
