def getCodeMap(WhichOne: str):
    # importing the file directory so an exact path is not needed
    import os

    cwd = os.getcwd()
    files = os.listdir(cwd)
    # importing the excel sheet
    import xlrd

    path = "Team6-Table.xls"
    wb = xlrd.open_workbook(path)
    sh = wb.sheet_by_index(0)
    print(sh.nrows)
    print(sh.ncols)
    # dictionary for values
    Bin2Char = {}
    Char2Bin = {}

    # for loop repeated certain amount of times to store short characters in dictionary
    # characters are the key

    for i in range(17):
        Schar = sh.cell(i, 1).value
        Sbinval = sh.cell(i, 0).value

        print(Sbinval, " : ", Schar)
        Char2Bin[Schar] = Sbinval
        Bin2Char[Sbinval] = Schar

        # for loop repeated certain amount of times to store long characters in dictionary
    for i in range(65):
        Lchar = sh.cell(i, 3).value
        Lbinval = sh.cell(i, 2).value

        print(Lbinval, " : ", Lchar)
        Char2Bin[Lchar] = Lbinval
        Bin2Char[Lbinval] = Lchar
    if WhichOne == "bin2char":
        return Bin2Char
    else:
        return Char2Bin


def decode(string: str):
    # taking file text which is binary and converting it back to string
    with open("BinOutput.txt") as f:
        my_list = f.readlines()
    my_list = my_list[0]
    #calls bin2char as dictionary
    Dict = getCodeMap("bin2char")

    #splits the decimal and the binary code and gets rid of .
    new = my_list.split(".")
    #starts a new list with the index starting after the decimal
    newlist = new[1]
    #determines length of character multiple times until end and adds to new list

    result = []
    vlist = [i for i in Dict.values()]
    klist = [i for i in Dict.keys()]
    index = 0
    while index <len(newlist):

        flag = newlist[index]
            #finding value long character
        if flag == "1":
            l = "".join(newlist[index:index+7])
            if l in Dict.keys():
                if l == "1110100":
                    result.append("\n")
                else:
                    ind = klist.index(l)
                    print(ind)
                    result.append(vlist[ind])
                index = index + 7

        #finding value of short character
        else:
            s = "".join(newlist[index:index+5])

            if s in Dict.keys():
                ind = klist.index(s)
                print(ind)
                result.append(vlist[ind])
                index = index + 5
    conv = "".join(result)
    f = open("BinOutput.txt", "w+")
    f.write(conv)
print(decode("BinOutput.txt"))
