def getCodeMap(WhichOne: str):
    # importing the file directory so an exact path is not needed
    import os

    cwd = os.getcwd()
    files = os.listdir(cwd)
    # importing the excel sheet
    import xlrd

    path = "Team6-Table.xls"
    wb = xlrd.open_workbook(path)
    sh = wb.sheet_by_index(0)
    print(sh.nrows)
    print(sh.ncols)
    # dictionary for values
    Bin2Char = {}
    Char2Bin = {}

    # for loop repeated certain amount of times to store short characters in dictionary
    # characters are the key

    for i in range(17):
        Schar = sh.cell(i, 1).value
        Sbinval = sh.cell(i, 0).value

        print(Sbinval, " : ", Schar)
        Char2Bin[Schar] = Sbinval
        Bin2Char[Sbinval] = Schar

        # for loop repeated certain amount of times to store long characters in dictionary
    for i in range(65):
        Lchar = sh.cell(i, 3).value
        Lbinval = sh.cell(i, 2).value

        print(Lbinval, " : ", Lchar)
        Char2Bin[Lchar] = Lbinval
        Bin2Char[Lbinval] = Lchar

        #says if we use Bin2Char dictionary or Char2Bin dictionary
    if WhichOne == "bin2char":
        return Bin2Char
    else:
        return Char2Bin

def code(string: str):
    #opens up txt file and converts it into a string
    with open(string) as f:
        #conv to list
        my_list= f.readlines()
    print(my_list)
    line = "".join(my_list)
    #calls first function and has "" as input, setting it to Char2Bin
    Dict = getCodeMap("")
    B = ""
    ind = 0
    while ind < len(line):
        if line[ind] != "\n":
            Bin = Dict[line[ind]]
        #calls dictionary and sets the binary value of it
        else:
            Bin = "1110100"
        #adds it to the string
        ind += 1
        B = B + Bin
    #states total length of binary code
    D = len(B)
    B = str(D) + "." + B
    f = open("BinOutput.txt", "w+")
    #writes in Binary to txt
    f.write(B)
    print(B)
    #calls the function to start with this txt to read
print(code("allChars.txt"))


